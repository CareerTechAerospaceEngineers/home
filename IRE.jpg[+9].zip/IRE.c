#include <stdio.h>
#include <cs50.h>
#include <math.h>
#include <string.h>

void userprompt();
void dvcalc();
void interpret();
void interpret2();
void posequestion();
void getdestination();
void art();

//Joel Trout, Reign Pagaran.  December 2017.

double F = 1;//where F represents the fully fueled mass of a payload delivery craft (kg)
double E = 1;//where E represents the empty (exhausted) mass of the same craft (kg)
double P = 1;//where P represents a payload mass to deliver to a target (kg)
double S = 1;//where S repersents the specific impulse of the craft's engines (seconds)
double dv = 1;//where DV represents Delta V; the ability of a spacecraft to move (m/s)
double I = 1;//where I represents the intermediate mass so that DV exhausted
//is constant as the craft delivers its payload
int rd[4] = {3940, 5710, 6790, 13080};//rd = required dv(Delta V)
int ignoreme = 0;// a variable that I use in my code that has no apparent purpose
int user_choice = 0;
int user_choice2 = 0;
//h is simply a random variable I could not think of n accurate descriptor
int h[3] = {1, 2, 3};
//r = remainder
int r = 0;
string planets[4] = {"Moon","Mars","Venus","Mercury"};

//The function of this program is to mathematically function as a useful method to calculate
//the DV a given "payload delivery craft" in Low Earth Orbit can provide.  Realize this program
//incorporates the ISP of the delivery craft's engines, the full and empty mass of the delivery
//craft, and finally the payload mass to determine this DV value. These calculations are based
//on formulas derived from the Ideal Rocket Equation, hence the program name.


int main(void)
{
    //Reign Code Start
    userprompt();
    dvcalc();
    //Reign Code End
    //Joel Code Start
    interpret(dv);
    posequestion();
    for(int again = 0; again < 1000; again++)
    {
        getdestination();

        posequestion();

        rd[0] = 3940;
        rd[1] = 5710;
        rd[2] = 6790;
        rd[3] = 13080;

        interpret(dv);
//Joels Code End
    }

}

void userprompt()
{
    //My portion of this code calculates the intermediate mass of a craft (I); this intermediate
    //mass represents how massive the delivery vehicle is after delivering payload P as far as
    //possible with equal DV on delivery and craft return to LEO.

    //PROBLEMS I HAD/OVERCAME WHILE CODING:
    //Issue with I formula: rejected format of formula, data type, etc (tried to multiply TI-83 style)
    //Program initially came up with illogical values for Intermediate Mass (-nan kg)
    //Solved this problem; reversed the sign on a portion of the equation (see assignment for math error)
    //nonworking equation  0.5 * (sqrt((P * P) - (4 * E * F) - (E * P * 4)) - P);
    F = get_double("What is the fully fueled mass of your delivery craft in kg?\n");
    E = get_double("What is the fuel-exhausted empty mass of your delivery craft in kg?\n");
    P = get_double("What is the payload mass your delivery craft will deliver in kg?\n");
    S = get_double("What is the specific impulse of your delivery craft's engines in seconds?\n");
    //calculates the intermediate mass I
    I = sqrt((P * P) + (4 * ((E * F) + (E * P)))) / 2;
    printf("\nIntermediate Mass: %f kg\n",I);
}

void dvcalc()
{
    //This portion of the code will take the Intermediate values and convert that into DV based on the values.
    dv = 9.81 * S * log(I / E);
    printf("DV: %f m/s.\n", dv);
    //As dv is a global variable, Joel's portion of the code will interpret DV as
    //ability to travel to other targets.
}

//Joels Functions
void interpret()
{
    printf("\n\nThe following table displays how many m/s of Delta V\nyou will need to expend in order\nto reach a given destination.\n\n");
    printf("\nDelta V at start is: %f m/s\nWhere would you like to go?\n\n", dv);
    r = dv;

    //Print Planets
    for(int i = 0; i < 4; i++)
    {
        ignoreme = i + 1;
        printf("%d. %s-------> %d\n", ignoreme, planets[i], rd[i]);
    }
    //Gets User Input
    posequestion();

    interpret2(dv);

    for(int again = 0; again < 100; again++)
    {
        getdestination();

        posequestion();

        rd[0] = 3940;
        rd[1] = 5710;
        rd[2] = 6790;
        rd[3] = 13080;

        interpret(dv);
    }
}

void interpret2()
{
    if(r >= rd[user_choice - 1])
    {
        printf("\nYou can make it to your destination!\n");
    }
        else if (r <= rd[user_choice - 1])
    {
        printf("\nSorry you will not make it :(\n");
        exit(0);
    }
    printf("\nDelta V left is: %d m/s\n", r);
    do
    {
        printf("\nWhat would you like to do now?\n");
        user_choice2 = get_int("\n1.Go Home(%d dv needed)\n2.Choose New Destination. Rechoosing a destination inferrs you are returning to Earth from that destination.\n3.Stay Here\n(choose 1, 2, or 3):", rd[user_choice - 1]);
    }
    while (user_choice2 > 3 || user_choice2 < 1);

    if (user_choice2 == h[0] && r >= rd[user_choice - 1])
    {
        r = r - rd[user_choice - 1];
        printf("\nYou can make it home with %d Delta V to spare!\nEnjoy the Trip :)\n", r);
        exit(0);
    }

    else if (user_choice2 == h[2])
    {
        printf("\nYou still have %d Delta V,\nEnjoy Your Stay :)\n", r);
        exit(0);
    }

    else if (user_choice2 == h[0] && r < rd[user_choice - 1])
    {
        printf("\nYou do not have enough DeltaV to make it home\nHope you planned on staying awhile\n");
        exit(0);
    }

    if (user_choice2 == h[1] && r > 0)
    {
        printf("\nDelta V left is: %d m/s\nHere is where you can go with remaining Delta V:\n", r);
        rd[0] = rd[0] + rd[user_choice - 1];
        rd[1] = rd[1] + rd[user_choice - 1];
        rd[2] = rd[2] + rd[user_choice - 1];
        rd[3] = rd[3] + rd[user_choice - 1];
    }
}
    void posequestion()
    {

     do
        {
            printf("\nChoose your destination by typing in the number of the wanted reference line above:\n");
            user_choice = get_int();
        }
        while (user_choice > 4 || user_choice < 0 );
        r = r - rd[user_choice - 1];
    }

    void getdestination()
    {
        if (r >= rd[3])
        {
            for(int i = 0; i < 4; i++)
            {
                ignoreme = i + 1;
                printf("%d. %s-------> %d\n", ignoreme, planets[i], rd[i]);
            }
        }
        else if (r >= rd[2] && r < rd[3])
        {
            for(int i = 0; i < 3; i++)
            {
                ignoreme = i + 1;
                printf("%d. %s-------> %d\n", ignoreme, planets[i], rd[i]);
            }
        }
        else if (r >= rd[1] && r < rd[2])
        {
            for(int i = 0; i < 2; i++)
            {
                ignoreme = i + 1;
                printf("%d. %s-------> %d\n", ignoreme, planets[i], rd[i]);
            }
        }
        else if (r >= rd[0] && r < rd[1])
        {
            for(int i = 0; i < 1; i++)
            {
                ignoreme = i + 1;
                printf("%d. %s-------> %d\n", ignoreme, planets[i], rd[i]);
            }
        }
        else
        {
            printf("\nYou do not have enough Delta V to go anywhere\n");
            exit(0);
        }
}
//End of Joels Functions
